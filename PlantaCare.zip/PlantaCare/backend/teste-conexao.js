
const conexao = require('./conexao');

async function testarConexao() {
    try {
        const [resultado] = await conexao.query(
            'SELECT DATABASE() AS banco'
        );

        console.log('Conexao realizada!');
        console.log('Banco:', resultado[0].banco);
    } catch (erro) {
        console.error('Erro na conexao:', erro.message);
    } finally {
        await conexao.end();
    }
}

testarConexao();
