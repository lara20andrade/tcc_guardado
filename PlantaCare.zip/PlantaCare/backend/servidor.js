
const express = require('express');
const cors = require('cors');
const conexao = require('./conexao');

const app = express();


const PORTA = 3000;

app.use(cors());
app.use(express.json());

// Rota inicial: verificar se a API está funcionando
app.get('/', (req, res) => {
    res.json({
        mensagem: 'API do PlantaCare funcionando!'
    });
});

// Consultar as plantas cadastradas
app.get('/api/plantas', async (req, res) => {
    try {
        const [plantas] = await conexao.execute(
            `SELECT id_planta, id_usuario, nome, especie,
                    localizacao, foto_url, umidade_minima,
                    umidade_maxima, data_cadastro
             FROM plantas
             ORDER BY id_planta DESC`
        );

        res.json(plantas);
    } catch (erro) {
        console.error('ERRO AO CONSULTAR PLANTAS:', erro);
        console.error('CÓDIGO DO ERRO:', erro.code);
        res.status(500).json({
            erro: 'Não foi possível consultar as plantas.'
        });
    }
});

/* Consultar uma planta específica pelo ID */
app.get('/api/plantas/:id', async (req, res) => {
    try {
        const idPlanta = Number(req.params.id);

        if (!Number.isInteger(idPlanta) || idPlanta <= 0) {
            return res.status(400).json({
                erro: 'ID da planta inválido.'
            });
        }

        const [plantas] = await conexao.execute(
            'SELECT * FROM plantas WHERE id_planta = ?',
            [idPlanta]
        );

        if (plantas.length === 0) {
            return res.status(404).json({
                erro: 'Planta não encontrada.'
            });
        }

        return res.json(plantas[0]);

    } catch (erro) {
        console.error(erro);

        return res.status(500).json({
            erro: 'Não foi possível consultar a planta.'
        });
    }
});

// Cadastrar uma planta

app.post('/api/plantas', async (req, res) => {
    try {
        console.log('ROTA DE CADASTRO EXECUTADA');

        const {
            id_usuario,
            nome,
            especie,
            localizacao,
            foto_url,
            umidade_minima,
            umidade_maxima
        } = req.body;
        const idUsuario = Number(id_usuario);

        if (!Number.isInteger(idUsuario) || idUsuario <= 0) {
            return res.status(400).json({
                erro: 'Informe um ID de usuário válido.'
            });
        }

        if (
            typeof nome !== 'string' || !nome.trim() ||
            typeof especie !== 'string' || !especie.trim()
        ) {
            return res.status(400).json({
                erro: 'Nome e espécie são obrigatórios.'
            });
        }

       const umidadeMinima =
    umidade_minima === undefined ? 40 : Number(umidade_minima);

       const umidadeMaxima =
    umidade_maxima === undefined ? 70 : Number(umidade_maxima);

       console.log('Umidade máxima recebida:', umidadeMaxima);
       console.log('VALIDAÇÃO EXECUTADA');
       console.log('Mínima:', umidadeMinima);
       console.log('Máxima:', umidadeMaxima);
        if (
            !Number.isFinite(umidadeMinima) ||
            !Number.isFinite(umidadeMaxima) ||
            umidadeMinima < 0 ||
            umidadeMinima > 100 ||
            umidadeMaxima < 0 ||
            umidadeMaxima > 100 ||
            umidadeMinima > umidadeMaxima
        ) {
            return res.status(400).json({
                erro: 'A umidade deve estar entre 0 e 100, e a mínima não pode ser maior que a máxima.'
            });
        }

        if (
            (localizacao != null && typeof localizacao !== 'string') ||
            (foto_url != null && typeof foto_url !== 'string')
        ) {

            return res.status(400).json({
                erro: 'Localização e foto_url devem ser textos.'
            });
        }

        const [resultado] = await conexao.execute(
            `INSERT INTO plantas
            (id_usuario, nome, especie, localizacao, foto_url,
             umidade_minima, umidade_maxima)
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                idUsuario,
                nome.trim(),
                especie.trim(),
                localizacao?.trim() || null,
                foto_url?.trim() || null,
                umidadeMinima,
                umidadeMaxima
            ]
        );

        return res.status(201).json({
            mensagem: 'Planta cadastrada com sucesso!',
            id_planta: resultado.insertId
        });

    } catch (erro) {
        console.error(erro);

        return res.status(500).json({
            erro: 'Não foi possível cadastrar a planta. Confira se o usuário existe no banco de dados.'
        });
    }
});


/* Atualizar os dados de uma planta */
app.patch('/api/plantas/:id', async (req, res) => {
    try {
        const idPlanta = Number(req.params.id);
        const {
            nome,
            especie,
            localizacao,
            foto_url,
            umidade_minima,
            umidade_maxima
        } = req.body;

        if (!Number.isInteger(idPlanta) || idPlanta <= 0) {
            return res.status(400).json({
                erro: 'ID da planta inválido.'
            });
        }

        const [plantasExistentes] = await conexao.execute(
            'SELECT * FROM plantas WHERE id_planta = ?',
            [idPlanta]
        );

        if (plantasExistentes.length === 0) {
            return res.status(404).json({
                erro: 'Planta não encontrada.'
            });
        }

        const plantaAtual = plantasExistentes[0];

        const novoNome = nome === undefined ? plantaAtual.nome : nome;
        const novaEspecie = especie === undefined ? plantaAtual.especie : especie;
        const novaLocalizacao = localizacao === undefined ? plantaAtual.localizacao : localizacao;
        const novaFoto = foto_url === undefined ? plantaAtual.foto_url : foto_url;

        const umidadeMinima = umidade_minima === undefined
            ? Number(plantaAtual.umidade_minima)
            : Number(umidade_minima);

        const umidadeMaxima = umidade_maxima === undefined
            ? Number(plantaAtual.umidade_maxima)
            : Number(umidade_maxima);

        if (
            typeof novoNome !== 'string' || !novoNome.trim() ||
            typeof novaEspecie !== 'string' || !novaEspecie.trim()
        ) {
            return res.status(400).json({
                erro: 'Nome e espécie devem ser textos não vazios.'
            });
        }

        if (
            (novaLocalizacao !== null && typeof novaLocalizacao !== 'string') ||
            (novaFoto !== null && typeof novaFoto !== 'string')
        ) {
            return res.status(400).json({
                erro: 'Localização e foto_url devem ser textos ou nulos.'
            });
        }

        if (
            !Number.isFinite(umidadeMinima) ||
            !Number.isFinite(umidadeMaxima) ||
            umidadeMinima < 0 || umidadeMinima > 100 ||
            umidadeMaxima < 0 || umidadeMaxima > 100 ||
            umidadeMinima > umidadeMaxima
        ) {
            return res.status(400).json({
                erro: 'A umidade deve estar entre 0 e 100, e a mínima não pode ser maior que a máxima.'
            });
        }

        await conexao.execute(
            `UPDATE plantas
             SET nome = ?, especie = ?, localizacao = ?, foto_url = ?,
                 umidade_minima = ?, umidade_maxima = ?
             WHERE id_planta = ?`,
            [
                novoNome.trim(),
                novaEspecie.trim(),
                novaLocalizacao,
                novaFoto,
                umidadeMinima,
                umidadeMaxima,
                idPlanta
            ]
        );

        return res.json({
            mensagem: 'Planta atualizada com sucesso!',
            id_planta: idPlanta
        });

    } catch (erro) {
        console.error(erro);

        return res.status(500).json({
            erro: 'Não foi possível atualizar a planta.'
        });
    }
});


/* Excluir uma planta */
app.delete('/api/plantas/:id', async (req, res) => {
    try {
        const idPlanta = Number(req.params.id);

        if (!Number.isInteger(idPlanta) || idPlanta <= 0) {
            return res.status(400).json({
                erro: 'ID da planta inválido.'
            });
        }

        const [plantasExistentes] = await conexao.execute(
            'SELECT id_planta FROM plantas WHERE id_planta = ?',
            [idPlanta]
        );

        if (plantasExistentes.length === 0) {
            return res.status(404).json({
                erro: 'Planta não encontrada.'
            });
        }

        await conexao.execute(
            'DELETE FROM plantas WHERE id_planta = ?',
            [idPlanta]
        );

        return res.json({
            mensagem: 'Planta excluída com sucesso!',
            id_planta: idPlanta
        });

    } catch (erro) {
        console.error(erro);

        return res.status(500).json({
            erro: 'Não foi possível excluir a planta. Verifique se existem registros relacionados.'
        });
    }
});


// Marcar uma notificação como lida
app.patch('/api/notificacoes/:id/lida', async (req, res) => {
    try {
        const idNotificacao = Number(req.params.id);

        if (!Number.isInteger(idNotificacao) || idNotificacao <= 0) {
            return res.status(400).json({
                erro: 'ID de notificação inválido.'
            });
        }

        const [resultado] = await conexao.execute(
            `UPDATE notificacoes
             SET lida = 1
             WHERE id_notificacao = ?`,
            [idNotificacao]
        );

        if (resultado.affectedRows === 0) {
            return res.status(404).json({
                erro: 'Notificação não encontrada.'
            });
        }

        return res.status(200).json({
            mensagem: 'Notificação marcada como lida com sucesso!',
            id_notificacao: idNotificacao
        });

    } catch (erro) {
        console.error(erro);

        return res.status(500).json({
            erro: 'Não foi possível marcar a notificação como lida.'
        });
    }
});


/* Consultar as notificações de uma planta */
app.get('/api/plantas/:id/notificacoes', async (req, res) => {
    try {
        const idPlanta = Number(req.params.id);

        if (!Number.isInteger(idPlanta) || idPlanta <= 0) {
            return res.status(400).json({
                erro: 'ID da planta inválido.'
            });
        }

        const [plantas] = await conexao.execute(
    'SELECT id_planta FROM plantas WHERE id_planta = ?',
    [idPlanta]
);

if (plantas.length === 0) {
    return res.status(404).json({
        erro: 'Planta não encontrada.'
    });
}

        const [notificacoes] = await conexao.execute(
            `SELECT id_notificacao, id_planta, titulo, mensagem,
                    tipo, lida, data_notificacao
             FROM notificacoes
             WHERE id_planta = ?
             ORDER BY data_notificacao DESC`,
            [idPlanta]
        );

        return res.status(200).json(notificacoes);

    } catch (erro) {
        console.error(erro);

        return res.status(500).json({
            erro: 'Não foi possível consultar as notificações.'
        });
    }
});

/* Registrar uma leitura manual ou simulada */
app.post('/api/plantas/:id/leituras', async (req, res) => {
    try {
        const idPlanta = Number(req.params.id);
        const { umidade, temperatura, origem } = req.body;

        if (!Number.isInteger(idPlanta) || idPlanta <= 0) {
            return res.status(400).json({
                erro: 'ID da planta inválido.'
            });
        }

        if (
            umidade === undefined ||
            !Number.isFinite(Number(umidade)) ||
            Number(umidade) < 0 ||
            Number(umidade) > 100
        ) {
            return res.status(400).json({
                erro: 'A umidade deve estar entre 0 e 100.'
            });
        }

        if (
            temperatura === undefined ||
            !Number.isFinite(Number(temperatura)) ||
            Number(temperatura) < -50 ||
            Number(temperatura) > 100
        ) {
            return res.status(400).json({
                erro: 'Informe uma temperatura válida entre -50 e 100 °C.'
            });
        }

        if (!['manual', 'simulada'].includes(origem)) {
            return res.status(400).json({
                erro: 'A origem deve ser manual ou simulada.'
            });
        }

        const [plantas] = await conexao.execute(
            'SELECT id_planta FROM plantas WHERE id_planta = ?',
            [idPlanta]
        );

        if (plantas.length === 0) {
            return res.status(404).json({
                erro: 'Planta não encontrada.'
            });
        }

        const [resultado] = await conexao.execute(
            `INSERT INTO leituras
             (id_planta, umidade, temperatura, origem)
             VALUES (?, ?, ?, ?)`,
            [idPlanta, Number(umidade), Number(temperatura), origem]
        );

                const [dadosPlanta] = await conexao.execute(
            `SELECT nome, umidade_minima, umidade_maxima
             FROM plantas
             WHERE id_planta = ?`,
            [idPlanta]
        );

        const planta = dadosPlanta[0];
        const umidadeAtual = Number(umidade);

               if (
            planta.umidade_minima !== null &&
            umidadeAtual < Number(planta.umidade_minima)
        ) {
            const [notificacoesExistentes] = await conexao.execute(
                `SELECT id_notificacao
                 FROM notificacoes
                 WHERE id_planta = ?
                   AND titulo = ?
                   AND lida = 0
                 LIMIT 1`,
                [idPlanta, 'Umidade baixa']
            );

            if (notificacoesExistentes.length === 0) {
                await conexao.execute(
                    `INSERT INTO notificacoes
                     (id_planta, titulo, mensagem, tipo)
                     VALUES (?, ?, ?, ?)`,
                    [
                        idPlanta,
                        'Umidade baixa',
                        `A planta ${planta.nome} está com umidade abaixo do mínimo recomendado.`,
                        'umidade'
                    ]
                );
            }
        } else if (
            planta.umidade_maxima !== null &&
            umidadeAtual > Number(planta.umidade_maxima)
        ) {
            const [notificacoesExistentes] = await conexao.execute(
                `SELECT id_notificacao
                 FROM notificacoes
                 WHERE id_planta = ?
                   AND titulo = ?
                   AND lida = 0
                 LIMIT 1`,
                [idPlanta, 'Umidade alta']
            );

            if (notificacoesExistentes.length === 0) {
                await conexao.execute(
                    `INSERT INTO notificacoes
                     (id_planta, titulo, mensagem, tipo)
                     VALUES (?, ?, ?, ?)`,
                    [
                        idPlanta,
                        'Umidade alta',
                        `A planta ${planta.nome} está com umidade acima do máximo recomendado.`,
                        'umidade'
                    ]
                );
            }
        }

        return res.status(201).json({
            mensagem: 'Leitura registrada com sucesso!',
            id_leitura: resultado.insertId
        });

    } catch (erro) {
        console.error(erro);

        return res.status(500).json({
            erro: 'Não foi possível registrar a leitura.'
        });
    }
});

/* Consultar o histórico de leituras de uma planta */
app.get('/api/plantas/:id/leituras', async (req, res) => {
    try {
        const idPlanta = Number(req.params.id);

        if (!Number.isInteger(idPlanta) || idPlanta <= 0) {
            return res.status(400).json({
                erro: 'ID da planta inválido.'
            });
        }

        const [plantas] = await conexao.execute(
    'SELECT id_planta FROM plantas WHERE id_planta = ?',
    [idPlanta]
);

if (plantas.length === 0) {
    return res.status(404).json({
        erro: 'Planta não encontrada.'
    });
}

        const [leituras] = await conexao.execute(
            `SELECT id_leitura, id_planta, umidade,
                    temperatura, origem, data_leitura
             FROM leituras
             WHERE id_planta = ?
             ORDER BY data_leitura DESC`,
            [idPlanta]
        );

        return res.status(200).json(leituras);

    } catch (erro) {
        console.error(erro);

        return res.status(500).json({
            erro: 'Não foi possível consultar as leituras.'
        });
    }
});


/* Consultar o histórico de regas de uma planta */
app.get('/api/plantas/:id/regas', async (req, res) => {
    try {
        const idPlanta = Number(req.params.id);

        if (!Number.isInteger(idPlanta) || idPlanta <= 0) {
            return res.status(400).json({
                erro: 'ID da planta inválido.'
            });
        }

        const [plantas] = await conexao.execute(
    'SELECT id_planta FROM plantas WHERE id_planta = ?',
    [idPlanta]
);

if (plantas.length === 0) {
    return res.status(404).json({
        erro: 'Planta não encontrada.'
    });
}

        const [regas] = await conexao.execute(
            `SELECT id_rega, id_planta, quantidade_agua_ml,
                    data_rega, observacao
             FROM regas
             WHERE id_planta = ?
             ORDER BY data_rega DESC`,
            [idPlanta]
        );

        return res.status(200).json(regas);

    } catch (erro) {
        console.error(erro);

        return res.status(500).json({
            erro: 'Não foi possível consultar o histórico de regas.'
        });
    }
});

/* Registrar uma rega */
app.post('/api/plantas/:id/regas', async (req, res) => {
    try {
        const idPlanta = Number(req.params.id);
        const { quantidade_agua_ml, observacao } = req.body;

        if (
    observacao !== undefined &&
    observacao !== null &&
    typeof observacao !== 'string'
) {
    return res.status(400).json({
        erro: 'A observação deve ser um texto.'
    });
}

        if (!Number.isInteger(idPlanta) || idPlanta <= 0) {
            return res.status(400).json({
                erro: 'ID da planta inválido.'
            });
        }

        if (
            quantidade_agua_ml !== undefined &&
            (
                !Number.isFinite(Number(quantidade_agua_ml)) ||
                Number(quantidade_agua_ml) <= 0
            )
        ) {
            return res.status(400).json({
                erro: 'A quantidade de água deve ser maior que zero.'
            });
        }

        const [plantas] = await conexao.execute(
            'SELECT id_planta FROM plantas WHERE id_planta = ?',
            [idPlanta]
        );

        if (plantas.length === 0) {
            return res.status(404).json({
                erro: 'Planta não encontrada.'
            });
        }

        const [resultado] = await conexao.execute(
            `INSERT INTO regas
             (id_planta, quantidade_agua_ml, observacao)
             VALUES (?, ?, ?)`,
            [
                idPlanta,
                quantidade_agua_ml === undefined
                    ? null
                    : Number(quantidade_agua_ml),
                observacao || null
            ]
        );

        return res.status(201).json({
            mensagem: 'Rega registrada com sucesso!',
            id_rega: resultado.insertId
        });

    } catch (erro) {
        console.error(erro);

        return res.status(500).json({
            erro: 'Não foi possível registrar a rega.'
        });
    }
});

app.listen(PORTA, () => {
    console.log(`API do PlantaCare rodando em http://localhost:${PORTA}`);
});
